function getFrequencyFromNote(note){
  var freq;
  switch(note){
    case 'H1dis':
      freq=261.626;
      break;
    case 'C':
      freq=261.626;
      break;
    case 'Cis':
      freq=277.183;
      break;
    case 'Des':
      freq=277.183;
      break;
    case 'D':
      freq=293.665;
      break;
    case 'Dis':
      freq=311.127;
      break;
    case 'Ees':
      freq=311.127;
      break;
    case 'E':
      freq=329.628;
      break;
    case 'F':
      freq=349.228;
      break;
    case 'Fis':
      freq=369.994;
      break;
    case 'Ges':
      freq=369.994;
      break;
    case 'G':
      freq=391.995;
      break;
    case 'Gis':
      freq=415.305;
      break;
    case 'As':
      freq=415.305;
      break;
    case 'A':
      freq=440;
      break;
    case 'Ais':
      freq=466.164;
      break;
    case 'B':
      freq=466.164;
      break;
    case 'H':
      freq=493.883;
      break;
    case 'C1u':
      freq=523.251;
      break;
    default:
      freq=440;
      break;
  }
  return freq;
}

//Alle meine Entchen
function playSongNum0(ii){
  var kk=ii%27;
  //document.getElementById("p3").innerHTML=kk.toString();
  switch(kk) {
    case 0:
      sin.set({freq:getFrequencyFromNote('C')});
      break;
    case 1:
      sin.set({freq:getFrequencyFromNote('D')});
      break;
    case 2:
      sin.set({freq:getFrequencyFromNote('E')});
      break;
    case 3:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 4:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 5:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 6:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 7:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 8:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 8:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 10:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 11:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 12:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 13:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 14:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 15:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 16:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 17:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 18:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 19:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 20:
      sin.set({freq:getFrequencyFromNote('E')});
      break;
    case 21:
      sin.set({freq:getFrequencyFromNote('E')});
      break;
    case 22:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 23:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 24:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 25:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 26:
      sin.set({freq:getFrequencyFromNote('C')});
      break;
  } 
  playBing();
}

//Tonleiter
function playSongNum1(ii){
  var kk=ii%8;
  //document.getElementById("p3").innerHTML=kk.toString();
  switch(kk) {
    case 0:
      sin.set({freq:getFrequencyFromNote('C')});
      break;
    case 1:
      sin.set({freq:getFrequencyFromNote('D')});
      break;
    case 2:
      sin.set({freq:getFrequencyFromNote('E')});
      break;
    case 3:
      sin.set({freq:getFrequencyFromNote('F')});
      break;
    case 4:
      sin.set({freq:getFrequencyFromNote('G')});
      break;
    case 5:
      sin.set({freq:getFrequencyFromNote('A')});
      break;
    case 6:
      sin.set({freq:getFrequencyFromNote('H')});
      break;
    case 7:
      sin.set({freq:getFrequencyFromNote('C1u')});
      break;
  } 
  playBing();
}

//Play a random sound in certain Frequency interval
function playRandomSound(){
  sin.set({freq:Math.floor(Math.random()*(varMaxFreq-varMinFreq))+varMinFreq});
  playBing();
}